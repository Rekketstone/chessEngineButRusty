# Screen Dimensions
WIDTH = 800 + 200  # 100 per square, 200 for sidebars
HEIGHT = 800
BOARD_WIDTH = 800
BOARD_HEIGHT = HEIGHT

# Board Dimensions
ROWS = 8
COLS = 8
SQSIZE = (BOARD_WIDTH) // COLS
